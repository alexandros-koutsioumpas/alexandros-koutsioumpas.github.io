The program runs in dialog mode by default.

By using the command line argument "-help" a brief user manual and description of the program is displayed.

A test run for Lysozyme (x-ray data) can be executed using the parameter file “lyz_run.txt". For example on linux platform by typing "./denfert_linux control.txt".

A test run for beta-Lactoglobulin (neutron data) can be executed using the parameter file “lyz_run.txt". For example on OSX platform by typing "./denfert_mac blac_run.txt".

Read the 'manual.pdf' for further instructions.